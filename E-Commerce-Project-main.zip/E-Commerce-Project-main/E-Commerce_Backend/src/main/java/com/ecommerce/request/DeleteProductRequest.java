package com.ecommerce.request;

public class DeleteProductRequest {
	
//	private Long 

}
