package com.ecommerce.response;

public class CreatePaymentLinkResponse {
	
	

}
