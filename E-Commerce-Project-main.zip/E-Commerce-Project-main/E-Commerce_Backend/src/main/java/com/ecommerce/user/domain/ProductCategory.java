package com.ecommerce.user.domain;

public enum ProductCategory {

	MALE,
	FEMALE
}
