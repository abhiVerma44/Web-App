package com.ecommerce.user.domain;

public enum ProductSubCategory {
	
	SHIRT,
	TSHIRT,
	SHOES,
	PAINT,
	SAREE,
	KURTA,
	WATCH

}
