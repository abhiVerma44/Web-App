package com.ecommerce.user.domain;

public enum UserRole {

	ROLE_ADMIN,
	ROLE_USER
}
