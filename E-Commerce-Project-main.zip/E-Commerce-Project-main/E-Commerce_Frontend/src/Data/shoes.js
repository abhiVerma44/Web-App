export const mensShoesPage1=[
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/l08gsy80/shoe/n/a/n/9-assg1015-9-abros-l-grey-maroon-original-imagc2m9zbzmtybx.jpeg?q=70",
        "brand": "Abros",
        "title": "ASSG1015N Running Shoes For Men",
        "color": "",
        "selling_price": "₹1,455",
        "price": "₹1,599",
        "disscount": "9% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/m/o/h/-original-imaggcawtbgvt7wy.jpeg?q=70",
        "brand": "asian",
        "title": "Oxygen-05 Running Shoes For Men",
        "color": "",
        "selling_price": "₹1,117",
        "price": "₹1,999",
        "disscount": "44% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/kqidx8w0/shoe/i/4/n/6-brd-406-300-blue-6-birde-blue-original-imag4g8cmfkfzkjg.jpeg?q=70",
        "brand": "BIRDE",
        "title": "Combo Pack of 2 Sports Shoes Running Shoes For Men",
        "color": "",
        "selling_price": "₹499",
        "price": "₹998",
        "disscount": "50% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/g/i/g/10-rng-2021-blu-orng-44-bruton-blue-orange-original-imagdzcpzhscxwhg-bb.jpeg?q=70",
        "brand": "BRUTON",
        "title": "Trendy Sports Running Running Shoes For Men",
        "color": "",
        "selling_price": "₹299",
        "price": "₹1,299",
        "disscount": "76% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/l4rd0280/shoe/m/d/e/6-rk-494-grey-orange-40-bruton-grey-orange-original-imagfha9ssgydnef.jpeg?q=70",
        "brand": "BRUTON",
        "title": "Sports shoes for men | Latest Stylish Casual for men |r...",
        "color": "",
        "selling_price": "₹249",
        "price": "₹1,299",
        "disscount": "80% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/c/k/k/gm1251-43-good-minar-black-original-imaft34ej4zx2z63-bb.jpeg?q=70",
        "brand": "aadi",
        "title": "Mesh |Lightweight|Comfort|Summer|Trendy|Walking|Outdoor...",
        "color": "",
        "selling_price": "₹199",
        "price": "₹999",
        "disscount": "80% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/kuzuoi80/shoe/2/k/x/7-brd-574-brd-575-7-birde-multicolor-original-imag7zx8epryeskm.jpeg?q=70",
        "brand": "BIRDE",
        "title": "Trendy Sport Shoes For Men Pack Of 2 Running Shoes For ...",
        "color": "",
        "selling_price": "₹499",
        "price": "₹1,498",
        "disscount": "66% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/1/8/p/-original-imaghvb7kkpy73vn.jpeg?q=70",
        "brand": "BRUTON",
        "title": "Trendy Sports Running Running Shoes For Men",
        "color": "",
        "selling_price": "₹249",
        "price": "₹1,299",
        "disscount": "80% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/q/r/j/-original-imagzjg25cg9wsrj.jpeg?q=70",
        "brand": "CAMPUS",
        "title": "MIKE (N) Running Shoes For Men",
        "color": "",
        "selling_price": "₹949",
        "price": "₹1,699",
        "disscount": "44% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/f/p/l/8-9326-8-world-wear-footwear-yellow-original-imagmengqep9gbwu.jpeg?q=70",
        "brand": "World Wear Footwear",
        "title": "Affordable Range of Stylish Casual Walking Comfortable ...",
        "color": "",
        "selling_price": "₹249",
        "price": "₹998",
        "disscount": "75% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/1/s/j/8-east-8-jqr-l-gry-original-imagjueg2zfewfpg.jpeg?q=70",
        "brand": "JQR",
        "title": "EAST COOLSENSE lightweight, trenndy stylish,strechable,...",
        "color": "",
        "selling_price": "₹811",
        "price": "₹1,249",
        "disscount": "35% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/s/j/9/-original-imaghrfzmsz9e6kh.jpeg?q=70",
        "brand": "NIVIA",
        "title": "Super Court 2.0 Badminton Shoes For Men",
        "color": "",
        "selling_price": "₹1,047",
        "price": "₹1,999",
        "disscount": "47% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/l4oi4cw0/shoe/g/u/e/6-blk-482-40-bruton-black-red-original-imagfgp97vzhyne2.jpeg?q=70",
        "brand": "BRUTON",
        "title": "Trendy Sports Running Running Shoes For Men",
        "color": "",
        "selling_price": "₹249",
        "price": "₹1,299",
        "disscount": "80% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/l0igvww0/shoe/j/x/z/7-brd-678-7-birde-blue-original-imagca7bcj6p99gw.jpeg?q=70",
        "brand": "BIRDE",
        "title": "Stylish Comfortable Lightweight, Breathable Black Runni...",
        "color": "",
        "selling_price": "₹299",
        "price": "₹999",
        "disscount": "70% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/i/k/r/-original-imaghugwugwyczwc.jpeg?q=70",
        "brand": "asian",
        "title": "Future-01 running shoes For Men",
        "color": "",
        "selling_price": "₹514",
        "price": "₹999",
        "disscount": "48% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/r/j/c/-original-imaghvb8a8hjrfmr.jpeg?q=70",
        "brand": "CAMPUS",
        "title": "STREET-RUN Running Shoes For Men",
        "color": "",
        "selling_price": "₹1,329",
        "price": "₹1,799",
        "disscount": "26% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/9/h/e/10-bd-1191bl-10-nivia-blue-original-imagndzhu9sgpyzf.jpeg?q=70",
        "brand": "NIVIA",
        "title": "Badminton Shoes For Men",
        "color": "",
        "selling_price": "₹896",
        "price": "₹1,120",
        "disscount": "20% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/f/h/e/7-rng-2cmb-2031-551-41-bruton-blue-white-original-imaggameyhax2hwu.jpeg?q=70",
        "brand": "BRUTON",
        "title": "omboPack of-2 | sports shoes for men |walking, gym, tre...",
        "color": "",
        "selling_price": "₹499",
        "price": "₹2,499",
        "disscount": "80% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/r/j/e/-original-imagmuc8gfb7heya.jpeg?q=70",
        "brand": "CAMPUS",
        "title": "HURRICANE Running Shoes For Men",
        "color": "",
        "selling_price": "₹1,054",
        "price": "₹1,299",
        "disscount": "18% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/1/e/a/-original-imaghvb5mhwjjasb.jpeg?q=70",
        "brand": "BRUTON",
        "title": "Trendy Sports Running Running Shoes For Men",
        "color": "",
        "selling_price": "₹299",
        "price": "₹1,299",
        "disscount": "76% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/6/0/r/10-cb-fast-white-rocky-black-10-sfr-multicolor-original-imagmgsbundpa9at.jpeg?q=70",
        "brand": "SFR",
        "title": "FAST Trenddy Tainer Lace-ups Sporty Casuals Running Sho...",
        "color": "",
        "selling_price": "₹489",
        "price": "₹1,699",
        "disscount": "71% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/l1jmc280/shoe/m/y/z/6-innova-04cwhtsky-asian-white-original-imagd3atfhw3tdwh.jpeg?q=70",
        "brand": "asian",
        "title": "Running Shoes For Men",
        "color": "",
        "selling_price": "₹1,099",
        "price": "₹1,999",
        "disscount": "45% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/ky1vl3k0/shoe/z/b/j/8-cosco-tan-density-tan-original-imagaderx2s5znkj.jpeg?q=70",
        "brand": "density",
        "title": "COSCO Training & Gym Shoes For Men",
        "color": "",
        "selling_price": "₹399",
        "price": "₹999",
        "disscount": "60% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/m/z/l/6-ori-9010-6-bersache-red-original-imagn69etxggadch.jpeg?q=70",
        "brand": "BERSACHE",
        "title": "Bersache Sports Shoes For Men|Red For Running,Walking,g...",
        "color": "",
        "selling_price": "₹649",
        "price": "₹3,842",
        "disscount": "83% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/l/n/4/-original-imaghvb4ew3j5x9v.jpeg?q=70",
        "brand": "ASE",
        "title": "Durable Performance Cricket Shoes with Dual Closure, La...",
        "color": "",
        "selling_price": "₹939",
        "price": "₹2,250",
        "disscount": "58% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/f/n/2/oxygen-4-airdron-white-navy-original-imafywywmhjcsyhy-bb.jpeg?q=70",
        "brand": "AIRDRON",
        "title": "Oxygen Running Shoes For Men",
        "color": "",
        "selling_price": "₹494",
        "price": "₹1,499",
        "disscount": "67% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/f/x/q/9-chrome-01-asian-white-original-imaggaz54tgkqyq6.jpeg?q=70",
        "brand": "asian",
        "title": "Chrome-01 White Sports,Casual,Walking,Stylish Running S...",
        "color": "",
        "selling_price": "₹1,299",
        "price": "₹2,299",
        "disscount": "43% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/d/r/r/-original-imaghsggbdxpvs9c.jpeg?q=70",
        "brand": "NIVIA",
        "title": "Ace Walking Shoes For Men",
        "color": "",
        "selling_price": "₹1,199",
        "price": "₹2,399",
        "disscount": "50% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/s/i/l/10-2031-blu-wht-44-bruton-blue-original-imagfmdubtgj8ebj-bb.jpeg?q=70",
        "brand": "BRUTON",
        "title": "Trendy Running Shoes Running Shoes For Men",
        "color": "",
        "selling_price": "₹349",
        "price": "₹1,299",
        "disscount": "73% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/d/m/z/-original-imagg7t26zdugnx8.jpeg?q=70",
        "brand": "KILLER",
        "title": "22509-T. Blue Phylon Running Shoes For Men",
        "color": "",
        "selling_price": "₹976",
        "price": "₹2,499",
        "disscount": "60% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/x/u/7/-original-imagg6rc839zxhw4.jpeg?q=70",
        "brand": "CAMPUS",
        "title": "NORTH PLUS Running Shoes For Men",
        "color": "",
        "selling_price": "₹1,299",
        "price": "₹1,699",
        "disscount": "23% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/y/i/n/7-brd-911-7-birde-navy-original-imaghq8zakm4mmgn.jpeg?q=70",
        "brand": "BIRDE",
        "title": "Premium Navy Sports Shoes For Men Walking Shoes For Men",
        "color": "",
        "selling_price": "₹715",
        "price": "₹1,999",
        "disscount": "64% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/u/z/q/-original-imagn24jy9bnpjsn.jpeg?q=70",
        "brand": "Reebok",
        "title": "Propulsion 2.0 M Running Shoes For Men",
        "color": "",
        "selling_price": "₹1,199",
        "price": "₹2,799",
        "disscount": "57% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/krz97rk0/shoe/p/w/8/11-54610-12-skechers-nvgy-original-imag5n6rkkmrhtqf.jpeg?q=70",
        "brand": "Skechers",
        "title": "Go Walk Max-Precision Walking Shoes For Men",
        "color": "",
        "selling_price": "₹2,657",
        "price": "₹5,299",
        "disscount": "49% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/o/v/e/6-rng-512-black-40-bruton-black-original-imagexnpgzqzzbze-bb.jpeg?q=70",
        "brand": "BRUTON",
        "title": "Trendy Sports Running Running Shoes For Men",
        "color": "",
        "selling_price": "₹299",
        "price": "₹1,299",
        "disscount": "76% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/knt7zbk0/shoe/m/r/r/7-5g-845-campus-gry-d-gry-original-imag2eynkpzvz6tf.jpeg?q=70",
        "brand": "CAMPUS",
        "title": "MIKE (N) Running Shoes For Men",
        "color": "",
        "selling_price": "₹942",
        "price": "₹1,699",
        "disscount": "44% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/xif0q/shoe/s/9/k/-original-imagg6r6yveqfsw9.jpeg?q=70",
        "brand": "Asics",
        "title": "GEL-CONTEND 4B Running Shoes For Men",
        "color": "",
        "selling_price": "₹1,693",
        "price": "₹3,999",
        "disscount": "57% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/k6fd47k0pkrrdj/shoe/x/g/s/9-cdnyafqbdq-world-wear-footwear-original-imafzrkveuhdgdy7.jpeg?q=70",
        "brand": "World Wear Footwear",
        "title": "Combo Pack of 2 Latest Collection Stylish casual Sports...",
        "color": "",
        "selling_price": "₹399",
        "price": "₹998",
        "disscount": "60% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/ksxjs7k0/shoe/o/g/7/9-6g-842-campus-blk-n-org-original-imag6dzwz7hdwgxh.jpeg?q=70",
        "brand": "CAMPUS",
        "title": "HURRICANE Running Shoes For Men",
        "color": "",
        "selling_price": "₹759",
        "price": "₹1,299",
        "disscount": "41% off",
        "size": ""
    },
    {
        "image": "https://rukminim1.flixcart.com/image/612/612/kzblocw0/shoe/l/i/f/9-crystal-13cblkrd-asian-black-original-imagbdaykm9wfnmz.jpeg?q=70",
        "brand": "asian",
        "title": "Crystal-13 Black Sports Transparent Sole Technology For...",
        "color": "",
        "selling_price": "₹1,259",
        "price": "₹2,299",
        "disscount": "45% off",
        "size": ""
    }
]