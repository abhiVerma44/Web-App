const IMAGES ={
    // imgOne: require('./Ecomm logo small.png'),
    imgTwo: require('./femshalogo.png')
  }

  export default IMAGES;
